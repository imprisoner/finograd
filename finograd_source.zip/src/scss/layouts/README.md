# layouts folder
    styles for layouts and layout components like header, footer, etc