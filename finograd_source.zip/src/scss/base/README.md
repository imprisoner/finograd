# base folder
    styles for simple components like buttons, icons, etc