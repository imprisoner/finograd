# abstracts folder
    configuration files, variables, etc.
    