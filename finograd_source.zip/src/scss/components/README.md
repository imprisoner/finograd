# components folder
    styles small blocks including base components