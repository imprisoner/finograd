# layouts folder
    layout components (header, footer, etc.) and layouts to extend pages from