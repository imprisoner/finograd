# blocks folder
    repeated static structures like sections, repeated on more than one place