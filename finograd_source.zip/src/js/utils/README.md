# utils folder
    utils can be imported in common or page js files